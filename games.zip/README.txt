*DISCLAIMER*

THIS IS NOT MY BOT I AM SIMPLY SHARING IT TO CRACKED.TO FORUM

Credit to rarep

Bot preview: https://imgur.com/a/4caI02a